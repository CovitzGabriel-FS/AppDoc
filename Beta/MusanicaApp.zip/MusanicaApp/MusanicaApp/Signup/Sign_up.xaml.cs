﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using MusanicaApp.Modal;
using Xamarin.Forms;

namespace MusanicaApp
{
    public partial class Sign_up : ContentPage
    {
        //User user 
        public Users user;
        //list of users
        private List<Users> _Users;
        //sign up
        public Sign_up()
        {
            InitializeComponent();
            //if clicked for sign up
            SignupButton.Clicked += SignupButton_Clicked;
        }
        //sign up method for when its clicked
        private async void SignupButton_Clicked(object sender, EventArgs e)
        {
            //instantiates user list
            _Users = new List<Users>();
            //gets the file
            var Files = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "LoginCred.txt");
            //if the button is enable make sit true
                SignupButton.IsEnabled = true;
            //if the file exist
            if (File.Exists(Files))
            {
                //if all are true it will proceed with the sign up but if not then error message appears
                if (SignFirst.Text != null && SignLast.Text != null && SignEmail.Text != null && SignPass.Text != null && SignRePass.Text != null && SignUsername.Text != null)
            {
                    if (SignPass.Text == SignRePass.Text && SignEmail.Text.Contains("@"))
                    {
                        //creates a user
                        user = new Users(SignUsername.Text, SignPass.Text, SignEmail.Text, SignFirst.Text, SignLast.Text);
                        //adds the user to the list
                        _Users.Add(user);
                        //stream writer writes the selected information like the symbol and image string
                        using (StreamWriter writer = new StreamWriter(Files))
                        {
                            //writes uer to file
                            writer.WriteLine($"{SignUsername.Text},{SignPass.Text},{SignEmail.Text}, {SignFirst}, {SignLast}");
                        }
                        //pop up
                        await DisplayAlert("Alert", "Your account has been created!", "OK");
                        //moves to next screen
                        await Navigation.PushAsync(new MainPage());
                    }
                    else
                    {
                        //validation
                        await DisplayAlert("Error", "Username or password is incorrect/taken or email is not valid", "OK");
                        SignPass.Text = "";
                        SignRePass.Text = "";
                        SignEmail.Text = "";
                    }
                }
                else
                {
                    //validation
                    await DisplayAlert("Error", "Please make sure you fill out all information", "OK");
                }
            }
                else
                {
                //validation
                await DisplayAlert("Error", "File not found", "OK");
   
                }

            }
        }
    }
   
