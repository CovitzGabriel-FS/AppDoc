﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MusanicaApp.ModalPages
{
    public partial class AddPlaylist : ContentPage
    {
        public AddPlaylist()
        {
            InitializeComponent();
            PlaylistButton.Clicked += PlaylistButton_Clicked;
            SongButton.Clicked += SongButton_Clicked;
            
        }

        private async void SongButton_Clicked(object sender, EventArgs e)
        {
            var detailPage = new AddSong();

            await Navigation.PushModalAsync(detailPage);
        }

        private async void PlaylistButton_Clicked(object sender, EventArgs e)
        {
            await DisplayAlert("Alert", "New playlist Created!", "OK");
            //moves to next screen
            await Navigation.PopModalAsync();
        }
    }
}
