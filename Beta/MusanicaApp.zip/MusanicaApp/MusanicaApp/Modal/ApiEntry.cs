﻿using System;
using System.Diagnostics;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MusanicaApp.Modal
{
    public class ApiEntry
    {

        //web client
        WebClient apiconnection = new WebClient();
        //api string
        string TrackAPI = "https://api.napster.com/v2.2/artists/Art.28463069/tracks/top?apikey=MGU2NzFiNDAtZTBjZi00MTBlLTlhZDMtZTZhZmMyOGM5NTBm&limit=5";
        string SearchAPI = "http://api.napster.com/v2.2/search/verbose?apikey=MGU2NzFiNDAtZTBjZi00MTBlLTlhZDMtZTZhZmMyOGM5NTBm&offset=1&per_type_limit=1&query=";
        string GenreAPI = "http://api.napster.com/v2.2/genres?apikey=MGU2NzFiNDAtZTBjZi00MTBlLTlhZDMtZTZhZmMyOGM5NTBm";
        string playlistAPI = "https://api.napster.com/v2.2/playlists?apikey=MGU2NzFiNDAtZTBjZi00MTBlLTlhZDMtZTZhZmMyOGM5NTBm";
        //property
        public string Name { get; set; }
       private JObject Artists { get; set; }
        private JObject Genres { get; set; }
        private JObject Searches { get; set; }
        public APi api;
        //a[i for tracks
        string apiEndPoint
        {
            get
            {
                return TrackAPI;
            }
        }
        //api for playlist
        string PlaylistEndPoint
        {
            get
            {
                return playlistAPI;
            }
        }
        //api for searchbar
        string SearchEndPoint
        {
            get
            {
                return SearchAPI + Name;
            }
        }
        //api for genre 
        string genreEndpoint
        {
            get
            {
                return GenreAPI;
            }
        }
        //donwloads the returned stirng
        public ApiEntry(string symbolsToDownLoad)
        {
            Name = symbolsToDownLoad;
        }
        //gets track/artist
        public async Task<APi> GetArtist()
        {
            string apistring = await apiconnection.DownloadStringTaskAsync(apiEndPoint);
            JObject jsonData = JObject.Parse(apistring);
            //puls the api data
            Artists = (JObject)jsonData["tracks"][0];
            //lets me see the api in console
            Debug.WriteLine(jsonData.ToString());
            api = new APi();
            //what i am trying to pull from the api
            api.ArtistsName = Artists["artistName"].ToString();
            api.Album = Artists["albumName"].ToString();
            api.Name = Artists["name"].ToString();
            return api;
        }
        //gets the genre
        public async Task <APi> GetGenre()
        {
            string apistringGenre = await apiconnection.DownloadStringTaskAsync(genreEndpoint);
            JObject jsonDataGenre = JObject.Parse(apistringGenre);
           // Debug.WriteLine(jsonDataGenre.ToString());
            Genres = (JObject)jsonDataGenre["genres"][0];
            api = new APi();
            //gets the list 
          List<JObject>  apilist= new List<JObject>();

            //sends the object 
            MessagingCenter.Subscribe<APi>(this, "ModifiedMessage", (sender) =>
            {
                foreach (JObject result in jsonDataGenre["genres"]["id"])
                {
                    apilist.Add(result);
                }
                Debug.WriteLine(sender);
            });
            api.ID = Genres["id"].ToString();
            api.Description = Genres["description"].ToString();
            return api;
        }
        //gets the searbar and pulls the data from the api
        public async Task<APi> GetSearch()
        {
            api = new APi();
            string apistringSearch = await apiconnection.DownloadStringTaskAsync(SearchEndPoint);
            JObject jsonDataSearch = JObject.Parse(apistringSearch);
            Searches = (JObject)jsonDataSearch["search"];
            Debug.WriteLine(jsonDataSearch.ToString());
            api.Search = Searches["search"].ToString();
            return api;
        }
        //gets the playlist and pulls specific data from the api
        public async Task<APi> Getplaylist()
        {
            api = new APi();
            string apistringplaylist = await apiconnection.DownloadStringTaskAsync(PlaylistEndPoint);
            JObject jsonDataSearch = JObject.Parse(apistringplaylist);
            Searches = (JObject)jsonDataSearch["playlists"][0];
            Debug.WriteLine(jsonDataSearch.ToString());
            api.Name = Searches["name"].ToString();
            api.Search = Searches["images"].ToString();
            return api;
        }

    }
}

