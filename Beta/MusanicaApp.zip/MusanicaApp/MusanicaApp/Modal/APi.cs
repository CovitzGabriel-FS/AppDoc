﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace MusanicaApp.Modal
{
    public class APi
    {
        //properties
        public string ArtistsName { get; set; }
        public string Album { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Search { get; set; }
        public string ID { get; set; }
        public string images { get; set; }
        public string searchimage { get; set; }
        public string Filename { get; set; }
        //genredata class for getting the images
        public class Genredata
        {
            //get sid
            public List<APi> ID { get; set; }
            public static List<APi> Get()
            {
               //returns list of images
                return new List<APi>
                {
                    new APi() { Name = "pop", images = $"https://api.napster.com/imageserver/images/g.290/240x160.jpg" },
                      new APi() { Name = "Metal", images = $"https://api.napster.com/imageserver/images/g.123/240x160.jpg" },
                        new APi() { Name = "hard metal", images = $"https://api.napster.com/imageserver/images/g.464/240x160.jpg" },
                          new APi() { Name = "calm", images = $"https://api.napster.com/imageserver/images/g.472/240x160.jpg" },
                            new APi() { Name = "chill", images = $"https://api.napster.com/imageserver/images/g.1027/240x160.jpg" },
                              new APi() { Name = "R&B", images = $"https://api.napster.com/imageserver/images/g.120/240x160.jpg" },
                                new APi() { Name = "popular", images = $"https://api.napster.com/imageserver/images/g.191/240x160.jpg" },
                                  new APi() { Name = "fan favorites", images = $"https://api.napster.com/imageserver/images/g.4/240x160.jpg" },
                                    new APi() { Name = "new", images = $"https://api.napster.com/imageserver/images/g.178/240x160.jpg" },
                                      new APi() { Name = "old", images = $"https://api.napster.com/imageserver/images/g.24/240x160.jpg" }
            };
            }
        }
        //gets image sfor playlist
        public class playlistimages
        {
            public static List<APi> Get()
            {
                
                return new List<APi>
                    {
                           new APi(){Name="Random Songs",   images="https://api.napster.com/imageserver/v2/playlists/pp.104529490/artists/images/230x153.jpg?montage=3x2"},

                                           new APi(){Name="Fishing music",   images="https://api.napster.com/imageserver/v2/playlists/pp.214725454/artists/images/230x153.jpg"},

                                                   new APi(){Name="everyday music",   images="https://api.napster.com/imageserver/v2/playlists/pp.227349347/artists/images/230x153.jpg"},

                                                           new APi(){Name="friends playlist",   images="https://api.napster.com/imageserver/v2/playlists/pp.234639838/artists/images/230x153.jpg"},

                                                                   new APi(){Name="new rock",   images="https://api.napster.com/imageserver/v2/playlists/pp.180234724/artists/images/230x153.jpg?"},



                    };

            }
        }
    }
}

    

