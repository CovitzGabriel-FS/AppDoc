﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace MusanicaApp.Modal
{
    public class Users : ContentPage
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public Users(string username, string password, string email, string firstname, string lastname)
        {
            Username = username;
            Password = password;
            Email = email;
            Firstname = firstname;
            Lastname = lastname;
            }
    }
    }


