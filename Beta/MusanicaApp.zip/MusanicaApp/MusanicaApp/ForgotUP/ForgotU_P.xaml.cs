﻿using System;
using System.Collections.Generic;
using MusanicaApp.Modal;
using Xamarin.Forms;

namespace MusanicaApp
{
    public partial class ForgotU_P : ContentPage
    {
        //user list
        List<Users> Users;
        public ForgotU_P()
        {
            InitializeComponent();
            SendButton.Clicked += SendButton_Clicked;
            ButtonBack.Clicked += ButtonBack_Clicked;
        }

        private async void ButtonBack_Clicked(object sender, EventArgs e)
        {
            //goes back to login page
            await Navigation.PopToRootAsync();
        }

        private void SendButton_Clicked(object sender, EventArgs e)
        {
            //all the code
            Forgot();
        }
        public async void Forgot()
        {
            //gets users list
            Users = new List<Users>();
            //loops through list
            foreach (var userinfo in Users)
            {
                MessagingCenter.Send<ForgotU_P>(this, "readfile");
                if (userinfo.Email.Contains(Emailrecover.Text))
                {
                    //moves to next screen
                    await DisplayAlert("Alert", $"Hello {userinfo.Firstname}!, You username:{userinfo.Username}, and your password:{userinfo.Password}", "OK");
                    await Navigation.PopToRootAsync();
                }
                else
                {
                    await DisplayAlert("Alert", "The email cannot be found, please try again.", "OK");
                }
            }
        }
    }
}
