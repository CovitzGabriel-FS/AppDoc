﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MusanicaApp.Modal;
using Xamarin.Forms;

namespace MusanicaApp
{
    public partial class MainPage : ContentPage
    {
        //api data
        Users apidata;
        //list of users
        List<Users> _Users;
        //a list to reads the user cred
        private List<APi> list = new List<APi>();
        //file location
        public MainPage()
        {
            InitializeComponent();
            Signbutton.Clicked += Signbutton_Clicked;
            LoginButton.Clicked += LoginButton_Clicked;
            UPButton.Clicked += UPButton_Clicked;

        }
        //goes to the forgot user or pass page
        private async void UPButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new ForgotU_P());
        }
        // on appearing
        protected override void OnAppearing()
        {
            base.OnAppearing();
            MessagingCenter.Subscribe<Users>(this, "Login and password info", (sender) =>
            {
                apidata = sender;
                LoginUsername.Text = apidata.Username;
                LoginPassword.Text = apidata.Password;
                
            });
            //clears list
            list.Clear();
        }
        //login button
        private void LoginButton_Clicked(object sender, EventArgs e)
        {
            //load method
            Load();
        }
        public async void Load()
        {

            //field list
            _Users = new List<Users>();
            //gets file
            var File = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "LoginCred.txt");
            //loops through the file and submit it to debug
            foreach (var fileinfo in File)
            {
                Debug.WriteLine(fileinfo);
            }
            //sends a message to read the file
            MessagingCenter.Subscribe<Users>(this, "readfile", (sender) =>
            {
                //txt file reader
                using (StreamReader sr = new StreamReader(File))
                {
                    string line;
                    //reads one line
                    while ((line = sr.ReadLine()) != null)
                    {
                        //splits lines
                        string[] data = line.Split(',');

                        //object
                        Users userinfo = new Users(data[0], data[1], data[2], data[3], data[4]);
                        //adds object to list
                        _Users.Add(userinfo);

                    }
                }
            });
            //txt file reader
            using (StreamReader sr = new StreamReader(File))
            {
                string line;
                //reads one line
                while ((line = sr.ReadLine()) != null)
                {
                    //splits lines
                    string[] data = line.Split(',');

                    //object
                    Users userinfo = new Users(data[0], data[1], data[2], data[3], data[4]);
                    //adds object to list
                    _Users.Add(userinfo);

                }
            }
            //loops through users
            foreach (var userinfo in _Users)
            {
                //sends the login and password info
                MessagingCenter.Send<MainPage>(this, "Login and password info");
                //if username that you enter equals the file name username and password then it lets you in
                if (LoginUsername.Text == userinfo.Username && LoginPassword.Text == userinfo.Password)
                {
                    //pop up
                    await DisplayAlert("Alert", "You have been logged in", "OK");

                    await Navigation.PushAsync(new Search_Page());
                }
                else
                {
                    //popup
                    await DisplayAlert("Alert", "your username or password is incorrect", "OK");
                }
            }


        }
        //sign button clicked
        private async void Signbutton_Clicked(object sender, EventArgs e)
        {
            //moves to next screen
            await Navigation.PushAsync(new Sign_up());
        }
    }
}
