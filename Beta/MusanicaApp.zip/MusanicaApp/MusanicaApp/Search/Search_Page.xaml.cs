﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using MusanicaApp.Modal;
using Xamarin.Forms;

namespace MusanicaApp
{
    public partial class Search_Page : ContentPage
    {
        //api entry
        ApiEntry entry;
        //api info
        APi info;
        //new data list
        List<APi> newdata = new List<APi>();
        public Search_Page()
        {
            InitializeComponent();
            Browse.Clicked += Browse_Clicked;
            Playlist.Clicked += Playlist_Clicked;
            Category.Clicked += Category_Clicked;
            LogoutButton.Clicked += LogoutButton_Clicked;
            Searchinfo.TextChanged += Searchinfo_TextChanged;
            //binds to the image cell
            DataTemplate dt = new DataTemplate(typeof(ImageCell));
            dt.SetBinding(TextCell.TextProperty, new Binding("Artist"));
            dt.SetBinding(ImageCell.ImageSourceProperty, new Binding("Image"));
            list.ItemTemplate = dt;
        }

        private void Searchinfo_TextChanged(object sender, TextChangedEventArgs e)
        {
            //search method
            Search();
            //save method
            Save();
        }
        private void Save()
        {
            //binding context for stock on apidata 
            var api = (APi)BindingContext;
            string filename = Path.Combine(App.FolderPath, $"{Path.GetRandomFileName()}.stockdatafile.txt");
            //if the file exist
            if (File.Exists(filename))
            {
                filename = api.Filename;
                //stream writer writes the selected information like the symbol and image string
                using (StreamWriter writer = new StreamWriter(filename))
                {
                    writer.WriteLine(api.ArtistsName, api.searchimage);
                }
            }
            //binds all this into a new api class
            BindingContext = new APi();
        }
        //logout button
        private async void LogoutButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new MainPage());
        }
        // performs a search
        public async void Search() 
        {
            //binding for text
            var Name = BindingContext as APi;
            //pulls the first json data from the api
            entry = new ApiEntry("Name");
            //the binding is then equal to the api information
            Name = await entry.GetSearch();

            Name.Name = Searchinfo.Text;

        }
        public void Reload()
        {
            newdata.Clear();
            //id the list is not null
            if (newdata != null)
            {
                //file locaton
                var files = Directory.EnumerateFiles(App.FolderPath, $"{Path.GetRandomFileName()}.stockdatafile.txt");
                //foreach item in the file
                foreach (var item in files)
                {
                    //reads the item
                    using (StreamReader sr = new StreamReader(item))
                    {
                        //defnes a variable
                        string line;
                        //while line is = to readline
                        while ((line = sr.ReadLine()) != null)
                        {
                            //the item will be added to the stocklist list
                            newdata.Add(new APi
                            {
                                Filename = item,
                                ArtistsName = line,
                                searchimage = line
                            });
                        }
                    }
                    //the list of itemssource will be on the stocklist
                    list.ItemsSource = newdata.ToList();

                }
            }
        }
        private async void Category_Clicked(object sender, EventArgs e)
        {

            await Navigation.PushAsync(new Category_Page());
        }

        private async void Playlist_Clicked(object sender, EventArgs e)
        {

            await Navigation.PushAsync(new Playlist_Page());
        }

        private async void Browse_Clicked(object sender, EventArgs e)
        {

            await Navigation.PushAsync(new Search_Page());
        }
    }
}
