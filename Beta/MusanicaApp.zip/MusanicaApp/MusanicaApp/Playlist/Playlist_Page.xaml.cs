﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using MusanicaApp.Modal;
using MusanicaApp.ModalPages;
using Xamarin.Forms;
using static MusanicaApp.Modal.APi;

namespace MusanicaApp
{
    public partial class Playlist_Page : ContentPage
    {
         
        public ObservableCollection<APi> imagedata;
        public Playlist_Page()
        {
            InitializeComponent();
            
            Browse.Clicked += Browse_Clicked;
            Playlist.Clicked += Playlist_Clicked;
            Category.Clicked += Category_Clicked;
            LogoutButton.Clicked += LogoutButton_Clicked;
            AddPlaylistButton.Clicked += AddPlaylistButton_Clicked;
            
            //gets the images from the api
            this.imagedata = new ObservableCollection<APi>(playlistimages.Get());

        }
        private async void LogoutButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new MainPage());
        }
        private async void AddPlaylistButton_Clicked(object sender, EventArgs e)
        {
            var detailPage = new AddPlaylist();

            await Navigation.PushModalAsync(detailPage);
        }
        protected override async void OnAppearing()
        {
            collectionview.ItemsSource = imagedata;
            collectionview2.ItemsSource = imagedata;
            
            //binding for text
            APi Name;
            //pulls the first json data from the api
            ApiEntry dataManager = new ApiEntry("Name");
            //the binding is then equal tot he api information
            Name = await dataManager.Getplaylist();
            base.OnAppearing();
        }
        private async void Category_Clicked(object sender, EventArgs e)
        {

            await Navigation.PushAsync(new Category_Page());
        }

        private async void Playlist_Clicked(object sender, EventArgs e)
        {

            await Navigation.PushAsync(new Playlist_Page());
        }

        private async void Browse_Clicked(object sender, EventArgs e)
        {

            await Navigation.PushAsync(new Search_Page());
        }
    }
}
