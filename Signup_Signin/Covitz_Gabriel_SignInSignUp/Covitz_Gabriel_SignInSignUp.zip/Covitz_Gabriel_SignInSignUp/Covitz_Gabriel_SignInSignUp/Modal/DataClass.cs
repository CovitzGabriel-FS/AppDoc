﻿using System;
namespace Covitz_Gabriel_SignInSignUp.Modal
{
    public class DataClass
    {
        public  string Username { get; set; }
        public string Password { get; set; }
        public string RePassword { get; set; }
        public string Email { get; set; }
        public string Filename { get;  set; }

        public DataClass()
        {
        }
    }
}
