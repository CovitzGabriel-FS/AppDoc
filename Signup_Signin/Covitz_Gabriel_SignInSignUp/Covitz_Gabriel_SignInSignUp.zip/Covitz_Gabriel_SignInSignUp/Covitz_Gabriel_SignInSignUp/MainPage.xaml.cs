﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Covitz_Gabriel_SignInSignUp.Modal;
using System.Diagnostics;

namespace Covitz_Gabriel_SignInSignUp
{
    public partial class MainPage : ContentPage
    {
        DataClass Data = new DataClass();
        List<DataClass> info = new List<DataClass>();
        string filename = Path.Combine(App.FolderPath, $"{Path.GetRandomFileName()}.Signup.txt");
        public MainPage()
        {
            InitializeComponent();
            Signbutton.Clicked += Signbutton_Clicked;
            LoginButton.Clicked += LoginButton_Clicked;
            LoginPassword.IsPassword = true;
        }

        //logged in clikced
        private async void LoginButton_Clicked(object sender, EventArgs e)
        {
            //the list of itemssource will be on the stocklist
            if (LoginUsername.Text == Data.Username && LoginPassword.Text == Data.Password)
            {
                //makes inputs blank
                LoginUsername.Text = "";
                LoginPassword.Text= "";
                //pop up pass
                await DisplayAlert("Login Successfull", "Username or Password is correct", "Okay", "Cancel");
            }
            else
            {
                //makes fields blank
                LoginUsername.Text = "";
                LoginPassword.Text = "";
                //pop up fail
                await DisplayAlert("Login failed", "Username or Password is incorrect or not exists", "Okay", "Cancel");
            }

        }
        private async void Signbutton_Clicked(object sender, EventArgs e)
        {
            //moves to next screen
            await Navigation.PushAsync(new Signup());
        }
        protected override void OnAppearing()
        {

            if (File.Exists(filename))
            {
                filename = Data.Filename;
                var files = Directory.EnumerateFiles(App.FolderPath, $"{Path.GetRandomFileName()}.Signuptxt");
                foreach (var item in files)
                {
                    //reads the item
                    using (StreamReader sr = new StreamReader(item))
                    {
                        //defnes a variable
                        string line;
                        //while line is = to readline
                        while ((line = sr.ReadLine()) != null)
                        {

                            info.Add(new DataClass
                            {
                                Filename = item,
                                Username = line,
                                Password = line,
                            });
                            base.OnAppearing();
                            
                        }
                    }
                }
            }
        }
    }
}
              
        
    

            



