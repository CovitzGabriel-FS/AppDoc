﻿using System;
using System.Collections.Generic;
using System.IO;
using Xamarin.Forms;
using Covitz_Gabriel_SignInSignUp.Modal;
namespace Covitz_Gabriel_SignInSignUp
{
    public partial class Signup : ContentPage
    {
        public Signup()
        {
            InitializeComponent(); 
            SignButton.Clicked += SignButton_Clicked;
        }

        private async void SignButton_Clicked(object sender, EventArgs e)
        {
            if (SignPassword.Text == SignRePassword.Text && SignEmail.Text.Contains("@"))
            {
                    SignButton.IsEnabled = true;
                var data = (DataClass)BindingContext;
                string filename = Path.Combine(App.FolderPath, $"{Path.GetRandomFileName()}.Signup.txt");
                //if the file exist
                if (File.Exists(filename))
                {
                    filename = data.Filename;
                    //stream writer writes the selected information like the symbol and image string
                    using (StreamWriter writer = new StreamWriter(filename))
                    {
                        writer.WriteLine(SignUsername);
                        writer.WriteLine(SignPassword);
                        writer.WriteLine(SignEmail);
                    }
                    //binds all this into a new api class
                    BindingContext = new DataClass();
                }
                await Navigation.PopToRootAsync();
            }
            else
            {
                UsernameOrPassVal.Text = "Password's do not match or email is invalid.";
                SignPassword.Text = "";
                SignRePassword.Text =  "";
                SignEmail.Text = "";
            }
          
        }

    }
}
