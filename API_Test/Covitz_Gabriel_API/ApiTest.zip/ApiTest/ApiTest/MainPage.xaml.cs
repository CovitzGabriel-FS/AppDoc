﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using ApiTest.Modal;
using System.IO;
using System.Diagnostics;
// Gabriel Covitz
// 05 / 09  / 2021
namespace ApiTest
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            
        }
        protected override async void OnAppearing()
        {
            //binding for text
            var Name = BindingContext as api;
            //pulls the first json data from the api
            ApiEntry dataManager = new ApiEntry("0");
            //the binding is then equal tot he api information
            Name = await dataManager.GetArtist();
            //what i am trying to pull from the api
            artistname.Text = "artistname: " + Name.ArtistsName;
            album.Text = "Album: " + Name.Album;
            base.OnAppearing();
            //if string is not null then it will get the information
    
        }
    }
}
   
            
