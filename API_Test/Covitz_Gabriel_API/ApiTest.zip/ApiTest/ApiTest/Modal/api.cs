﻿using System;
namespace ApiTest.Modal
{
    public class api
    {
        public string ArtistsName { get; set; }
        public string Album{ get; set; }
        public string Filename { get; internal set; }

        public api()
        {
        }
    }
}
