﻿using System;
using System.Diagnostics;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace ApiTest.Modal
{
    public class ApiEntry
    {
        //web client
        WebClient apiconnection = new WebClient();
        //api string
        string startAPI = "https://api.napster.com/v2.2/artists/Art.28463069/tracks/top?apikey=MGU2NzFiNDAtZTBjZi00MTBlLTlhZDMtZTZhZmMyOGM5NTBm&limit=5";

 
        //property
        public string Name { get; set; }
        private JObject Artists { get; set; }
        string apiEndPoint
        {
            get
            {
                return startAPI;
            }
        }
        public ApiEntry(string symbolsToDownLoad)
        {
            Name = symbolsToDownLoad;
        }
        public async Task<api> GetArtist()
        {
            string apistring = await apiconnection.DownloadStringTaskAsync(apiEndPoint);
            JObject jsonData = JObject.Parse(apistring);
            //puls the api data
            Artists = (JObject)jsonData["tracks"][0];
            //lets me se the api in console
            Debug.WriteLine(jsonData.ToString());

            api apidata = new api();
            //what i am trying to pull from the api
            apidata.ArtistsName = Artists["artistName"].ToString();
            apidata.Album = Artists["albumName"].ToString();
            return apidata;
        }

    }
}
