﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace MusanicaApp.Modal
{
    public class APi
    {
        //properties
        public string ArtistsName { get; set; }
        public string Album { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Search { get; set; }
        public string ID { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string email { get; set; }
        public string images { get; set; }

        public string Filename { get; set; }
        //gets images source
        public ImageSource Genre
        {
            get
            {
                string web = "https://api.napster.com/imageserver/images/";
                string id = ID;
                string end = "/280x240.jpeg";

                return web + id + end;
            }
        }

        //genredata class for getting the images
        public class Genredata
        {
            public static List<APi> Get()
            {

                return new List<APi>
                    {
                     new APi(){Name="good music",  images="images.png" },
                         new APi(){Name="car ride",   images="images.png" },
                           new APi(){Name="chill music",   images="images.png" },
                               new APi(){Name="party",   images="images.png" },
                                   new APi(){Name="Calming",   images="images.png" },
                                        new APi(){Name="Rap",   images="images.png" },
                                             new APi(){Name="good music",  images="images.png" },
      
                    };

                }
            }
        }
    }

    

