﻿using System;
using System.Diagnostics;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MusanicaApp.Modal
{
    public class ApiEntry
    {

        //web client
        WebClient apiconnection = new WebClient();
        //api string
        string TrackAPI = "https://api.napster.com/v2.2/artists/Art.28463069/tracks/top?apikey=MGU2NzFiNDAtZTBjZi00MTBlLTlhZDMtZTZhZmMyOGM5NTBm&limit=5";
        string SearchAPI = "http://api.napster.com/v2.2/search/verbose?apikey=MGU2NzFiNDAtZTBjZi00MTBlLTlhZDMtZTZhZmMyOGM5NTBm&offset=1&per_type_limit=1&query=";
        string GenreAPI = "http://api.napster.com/v2.2/genres?apikey=MGU2NzFiNDAtZTBjZi00MTBlLTlhZDMtZTZhZmMyOGM5NTBm";
        //property
        string end = "&type=playlist";
        public string Name { get; set; }
       private JObject Artists { get; set; }
        private JObject Genres { get; set; }
        private JObject Searches { get; set; }
        string apiEndPoint
        {
            get
            {
                return TrackAPI;
            }
        }
        string SearchEndPoint
        {
            get
            {
                return SearchAPI + Name + end;
            }
        }
        string genreEndpoint
        {
            get
            {
                return GenreAPI;
            }
        }
        public ApiEntry(string symbolsToDownLoad)
        {
            Name = symbolsToDownLoad;
        }
        public async Task<APi> GetArtist()
        {
            string apistring = await apiconnection.DownloadStringTaskAsync(apiEndPoint);
            JObject jsonData = JObject.Parse(apistring);
            //puls the api data
            Artists = (JObject)jsonData["tracks"][0];
            //lets me see the api in console
            Debug.WriteLine(jsonData.ToString());
            APi apidata = new APi();
            //what i am trying to pull from the api
         apidata.ArtistsName = Artists["artistName"].ToString();
            apidata.Album = Artists["albumName"].ToString();
         apidata.Name = Artists["name"].ToString();
            return apidata;
        }
        public async Task<APi> GetGenre()
        {
            string apistringGenre = await apiconnection.DownloadStringTaskAsync(genreEndpoint);
            JObject jsonDataGenre = JObject.Parse(apistringGenre);
            Debug.WriteLine(jsonDataGenre.ToString());
            Genres = (JObject)jsonDataGenre["genres"][0];
            APi apidata = new APi();
            apidata.ID = Genres["id"].ToString();
            MessagingCenter.Subscribe<APi>(this, "ModifiedMessage", (sender) =>
            {
                apidata.ID = Genres["id"].ToString();
                Debug.WriteLine(sender);
            });
            apidata.Description = Genres["description"].ToString();
            return apidata;
        }
        public async Task<APi> GetSearch()
        {
            APi apidata = new APi();
            JObject jsonData = JObject.Parse(SearchAPI);
            string apistringSearch = await apiconnection.DownloadStringTaskAsync(SearchEndPoint);
            JObject jsonDataSearch = JObject.Parse(apistringSearch);
            Searches = (JObject)jsonData["search"][0];
            Debug.WriteLine(jsonDataSearch.ToString());
            apidata.Search = Searches["query"].ToString();
            return apidata;
        }

        }
}

