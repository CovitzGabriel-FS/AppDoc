﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MusanicaApp.Modal;
using Xamarin.Forms;

namespace MusanicaApp
{
    public partial class MainPage : ContentPage
    {
        //api data
        APi apidata;
        //a list to reads the user cred
        private List<APi> list = new List<APi>();
        //file location
        public MainPage()
        {
            InitializeComponent();
            Signbutton.Clicked += Signbutton_Clicked;
            LoginButton.Clicked += LoginButton_Clicked;
            UPButton.Clicked += UPButton_Clicked;

        }
        //goes to the forgot user or pass page
        private async void UPButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new ForgotU_P());
        }
        // on appearing
        protected override void OnAppearing()
        {
            base.OnAppearing();
            list.Clear();
            if (list != null)
            {
                //finds the file location
                var files = Directory.EnumerateFiles(App.FolderPath, $"{Path.GetRandomFileName()}.profileinfp.txt");
                //foreach item in the file
                foreach (var item in files)
                {
                    //reads the item
                    using (StreamReader sr = new StreamReader(item))
                    {
                        //defnes a variable
                        string line;
                        //while line is = to readline
                        while ((line = sr.ReadLine()) != null)
                        {
                            apidata.username = line;
                            apidata.password = line;
                        }
  
                    }
                }
            }
        }
        //login button
        private async void LoginButton_Clicked(object sender, EventArgs e)
        {
            apidata = new APi();
            //if username that you enter equals the file name username and password then it lets you in
            if (LoginUsername.Text == LoginPassword.Text)
            {
                //pop up
                await DisplayAlert("Alert", "You have been logged in", "OK");

                await Navigation.PushAsync(new Search_Page());
            }
            else
            {
                //popup
                await DisplayAlert("Alert", "your username or password is incorrect", "OK");
            }


        }
        private async void Signbutton_Clicked(object sender, EventArgs e)
        {
            //moves to next screen
            await Navigation.PushAsync(new Sign_up());
        }
    }
}
