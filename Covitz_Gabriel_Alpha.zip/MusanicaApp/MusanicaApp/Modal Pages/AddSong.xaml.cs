﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MusanicaApp.ModalPages
{
    public partial class AddSong : ContentPage
    {
        public AddSong()
        {
            InitializeComponent();
            SongSave.Clicked += SongSave_Clicked;
            BackButton.Clicked += BackButton_Clicked;
        }

        private async void BackButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopModalAsync();
        }

        private async void SongSave_Clicked(object sender, EventArgs e)
        {
            await DisplayAlert("Alert", "Selected songs have been added to the playlisy!", "Close");
            //moves to next screen
            await Navigation.PopModalAsync();
        }
    }
}
