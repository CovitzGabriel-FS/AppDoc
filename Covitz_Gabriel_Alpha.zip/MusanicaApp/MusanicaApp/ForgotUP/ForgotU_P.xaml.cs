﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MusanicaApp
{
    public partial class ForgotU_P : ContentPage
    {
        public ForgotU_P()
        {
            InitializeComponent();
            SendButton.Clicked += SendButton_Clicked;
        }

        private async void SendButton_Clicked(object sender, EventArgs e)
        {
            //moves to next screen
             await DisplayAlert("Alert", "an email has been sent to you email connected to the account", "OK");
            await Navigation.PopToRootAsync();
        }
    }
}
