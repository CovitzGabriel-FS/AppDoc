﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using MusanicaApp.Modal;
using Xamarin.Forms;

namespace MusanicaApp
{
    public partial class Sign_up : ContentPage
    {
        //api apidata
        private APi apidata;
        //sign up
        public Sign_up()
        {
            InitializeComponent();
            //if clicked for sign up
            SignupButton.Clicked += SignupButton_Clicked;
        }
        //sign up method for when its clicked
        private async void SignupButton_Clicked(object sender, EventArgs e)
        {
             apidata= new APi();
            //folder gets the random path .profile.txt
            var filename = Path.Combine(App.FolderPath, $"{Path.GetRandomFileName()}.ProfileInfo.txt");
            //if these conditions are correct it will let you sign up
            if (SignPass.Text == SignRePass.Text && SignEmail.Text.Contains("@"))
            {
                SignupButton.IsEnabled = true;
                //if the file exist
                if (File.Exists(filename))
                {
                    //filename is equal to the api filename
                    filename = apidata.Filename;
                    //stream writer writes the selected information like the symbol and image string
                    using (StreamWriter writer = new StreamWriter(filename))
                    {
                        writer.WriteLine(SignUsername);
                        writer.WriteLine(SignPass);
                        writer.WriteLine(SignEmail);
                    }
                    //binds all this into a new api class
                    BindingContext = new APi();
                }
                //pop up
                await DisplayAlert("Alert", "Your account has been created!", "OK");
                //moves to next screen
                await Navigation.PushAsync(new MainPage());
            }
            else
            {
                //validation
                UsernameOrPassVal.Text = "Password's do not match or email is invalid.";
                SignPass.Text = "";
                SignRePass.Text = "";
                SignEmail.Text = "";
            }
            }
        }
    }
   
