﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using MusanicaApp.Modal;
using Xamarin.Forms;

namespace MusanicaApp
{
    public partial class Search_Page : ContentPage
    {
        ApiEntry entry;
        public Search_Page()
        {
            InitializeComponent();
            Browse.Clicked += Browse_Clicked;
            Playlist.Clicked += Playlist_Clicked;
            Category.Clicked += Category_Clicked;
            LogoutButton.Clicked += LogoutButton_Clicked;

        }
        //logout button
        private async void LogoutButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new MainPage());
        }
        // performs a earch
        public ICommand PerformSearch => new Command<string>(async (string query) =>
        {
            //binding for text
            var Name = BindingContext as APi;
            //pulls the first json data from the api
            entry = new ApiEntry("Name");
            //the binding is then equal tot he api information
            Name = await entry.GetSearch();

            Name.Name = Search.Text;

        });
    private async void Category_Clicked(object sender, EventArgs e)
        {

            await Navigation.PushAsync(new Category_Page());
        }

        private async void Playlist_Clicked(object sender, EventArgs e)
        {

            await Navigation.PushAsync(new Playlist_Page());
        }

        private async void Browse_Clicked(object sender, EventArgs e)
        {

            await Navigation.PushAsync(new Search_Page());
        }
    }
}
