﻿using System;
using System.Collections.Generic;
using MusanicaApp.Modal;
using Xamarin.Forms;
using System.Collections.ObjectModel;
using static MusanicaApp.Modal.APi;
using System.IO;
using System.Linq;

namespace MusanicaApp
{
    public partial class Category_Page : ContentPage
    {
        public List<APi> genre = new List<APi>();
        public ObservableCollection<APi> imagedata;
        public Category_Page()
        {
            InitializeComponent();
            Browse.Clicked += Browse_Clicked;
            Playlist.Clicked += Playlist_Clicked;
            Category.Clicked += Category_Clicked;
            LogoutButton.Clicked += LogoutButton_Clicked;
            this.imagedata = new ObservableCollection<APi>(Genredata.Get());
            
        }
        private async void LogoutButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new MainPage());
        }

        protected override async void OnAppearing()
        {
            collectionview2.ItemsSource = imagedata;
            //binding for text
            APi Name;
            //pulls the first json data from the api
            ApiEntry dataManager = new ApiEntry("Name");
            //the binding is then equal tot he api information
            Name = await dataManager.GetArtist();
            base.OnAppearing();
            
        }


        private async void Category_Clicked(object sender, EventArgs e)
        {

            await Navigation.PushAsync(new Category_Page());
        }

        private async void Playlist_Clicked(object sender, EventArgs e)
        {

            await Navigation.PushAsync(new Playlist_Page());
        }

        private async void Browse_Clicked(object sender, EventArgs e)
        {

            await Navigation.PushAsync(new Search_Page());
        }
    }
}
